#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// --- PIN DEFINITIONS ---
#define PIN_SOUND    32
#define PIN_CURRENT  34
#define PIN_VOLTAGE  35
#define PIN_TEMP     4
#define PIN_LED_GRN  27

// --- MODULE SETUP ---
Adafruit_SSD1306 display(128, 64, &Wire, -1);
OneWire oneWire(PIN_TEMP);
DallasTemperature tempSensor(&oneWire);

// --- DIGITAL TWIN CONSTANTS (Placeholders) ---
float R_a = 1.5;     // Armature Resistance
float K_e = 0.05;    // Back-EMF Constant
float K_t = 0.05;    // Torque Constant
float B = 0.001;     // Friction Coefficient
float T_load = 0.0;  // External load torque

unsigned long lastSampleTime = 0;
const int sampleInterval = 100; // 10Hz sampling

void setup() {
  Serial.begin(115200);
  pinMode(PIN_LED_GRN, OUTPUT);

  Wire.begin(21, 22);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("OLED failed"));
    for(;;);
  }

  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("Serial Stream: LIVE");
  display.display();

  tempSensor.begin();
  tempSensor.setWaitForConversion(false);
  tempSensor.requestTemperatures();

  delay(1000);

  // Print the CSV Header exactly once
  Serial.println("Time_ms,Voltage_V,Current_A,Temp_C,Sound_Raw,I_Theo_A,Residue_E_A");
}

void loop() {
  unsigned long currentTime = millis();

  if (currentTime - lastSampleTime >= sampleInterval) {
    lastSampleTime = currentTime;

    // --- 1. READ SENSORS ---
    int raw_voltage = analogRead(PIN_VOLTAGE);
    float volts = (raw_voltage / 4095.0) * 25.0;

    int raw_current = analogRead(PIN_CURRENT);
    float current_v = (raw_current / 4095.0) * 3.3;
    float amps = abs((current_v - 1.65) / 0.185);

    float tempC = tempSensor.getTempCByIndex(0);
    tempSensor.requestTemperatures();

    int raw_sound = analogRead(PIN_SOUND);

    // --- 2. MATH (Residue Generation) ---
    float i_theo = (volts * B + K_e * T_load) / (R_a * B + K_e * K_t);
    float r_E = abs(amps - i_theo);

    // --- 3. STREAM TO PC VIA SERIAL ---
    Serial.print(currentTime);   Serial.print(",");
    Serial.print(volts, 2);      Serial.print(",");
    Serial.print(amps, 3);       Serial.print(",");
    Serial.print(tempC, 2);      Serial.print(",");
    Serial.print(raw_sound);    Serial.print(",");
    Serial.print(i_theo, 3);     Serial.print(",");
    Serial.println(r_E, 3);

    // --- 4. UPDATE OLED ---
    display.clearDisplay();
    display.setCursor(0, 0);
    display.print("V: "); display.print(volts, 1);
    display.setCursor(64, 0);
    display.print("A: "); display.print(amps, 2);
    display.setCursor(0, 15);
    display.print("Temp: "); display.print(tempC, 1);
    display.setCursor(0, 30);
    display.print("Residue: "); display.print(r_E, 3);
    display.display();

    digitalWrite(PIN_LED_GRN, !digitalRead(PIN_LED_GRN));
  }
}
